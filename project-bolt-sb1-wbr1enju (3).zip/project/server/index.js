const express = require('express');
const cors = require('cors');
const multer = require('multer');
const nodemailer = require('nodemailer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, 'uploads');
fs.mkdir(uploadsDir, { recursive: true }).catch(console.error);

// Create data directory if it doesn't exist
const dataDir = path.join(__dirname, 'data');
fs.mkdir(dataDir, { recursive: true }).catch(console.error);

// File paths
const POSTS_FILE = path.join(dataDir, 'posts.json');
const ADMIN_FILE = path.join(dataDir, 'admin.json');

// Initialize data files
const initializeDataFiles = async () => {
  try {
    // Initialize posts file
    try {
      await fs.access(POSTS_FILE);
    } catch {
      await fs.writeFile(POSTS_FILE, JSON.stringify([]));
    }

    // Initialize admin file with default admin
    try {
      await fs.access(ADMIN_FILE);
    } catch {
      const hashedPassword = await bcrypt.hash('admin123', 10);
      const adminData = {
        username: 'admin',
        password: hashedPassword,
        email: 'zukhruf402@gmail.com'
      };
      await fs.writeFile(ADMIN_FILE, JSON.stringify(adminData));
    }
  } catch (error) {
    console.error('Error initializing data files:', error);
  }
};

// Email configuration
const transporter = nodemailer.createTransporter({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER || 'your-email@gmail.com',
    pass: process.env.EMAIL_PASS || 'your-app-password'
  }
});

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Helper functions
const readPosts = async () => {
  try {
    const data = await fs.readFile(POSTS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return [];
  }
};

const writePosts = async (posts) => {
  await fs.writeFile(POSTS_FILE, JSON.stringify(posts, null, 2));
};

const readAdmin = async () => {
  try {
    const data = await fs.readFile(ADMIN_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    return null;
  }
};

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    req.admin = decoded;
    next();
  } catch (error) {
    res.status(400).json({ message: 'Invalid token.' });
  }
};

// Routes

// Admin login
app.post('/api/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const admin = await readAdmin();

    if (!admin || admin.username !== username) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, admin.password);
    if (!validPassword) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { username: admin.username },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );

    res.json({ token, message: 'Login successful' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get all posts (public)
app.get('/api/posts', async (req, res) => {
  try {
    const posts = await readPosts();
    const { category, search } = req.query;
    
    let filteredPosts = posts;
    
    if (category && category !== 'All') {
      filteredPosts = filteredPosts.filter(post => post.category === category);
    }
    
    if (search) {
      const searchLower = search.toLowerCase();
      filteredPosts = filteredPosts.filter(post => 
        post.title.toLowerCase().includes(searchLower) ||
        post.excerpt.toLowerCase().includes(searchLower) ||
        post.content.toLowerCase().includes(searchLower)
      );
    }
    
    // Sort by date (newest first)
    filteredPosts.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    res.json(filteredPosts);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get single post by slug (public)
app.get('/api/posts/:slug', async (req, res) => {
  try {
    const posts = await readPosts();
    const post = posts.find(p => p.slug === req.params.slug);
    
    if (!post) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    res.json(post);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create new post (admin only)
app.post('/api/posts', verifyToken, upload.single('image'), async (req, res) => {
  try {
    const { title, content, excerpt, category, author } = req.body;
    const posts = await readPosts();
    
    // Generate slug from title
    const slug = title.toLowerCase()
      .replace(/[^a-z0-9 -]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-');
    
    // Check if slug already exists
    if (posts.find(p => p.slug === slug)) {
      return res.status(400).json({ message: 'Post with this title already exists' });
    }
    
    const newPost = {
      id: Date.now().toString(),
      title,
      slug,
      content,
      excerpt,
      category,
      author: author || 'Admin',
      date: new Date().toISOString(),
      image: req.file ? `/uploads/${req.file.filename}` : null
    };
    
    posts.push(newPost);
    await writePosts(posts);
    
    res.status(201).json(newPost);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update post (admin only)
app.put('/api/posts/:id', verifyToken, upload.single('image'), async (req, res) => {
  try {
    const posts = await readPosts();
    const postIndex = posts.findIndex(p => p.id === req.params.id);
    
    if (postIndex === -1) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    const { title, content, excerpt, category, author } = req.body;
    const existingPost = posts[postIndex];
    
    // Generate new slug if title changed
    let slug = existingPost.slug;
    if (title !== existingPost.title) {
      slug = title.toLowerCase()
        .replace(/[^a-z0-9 -]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-');
    }
    
    const updatedPost = {
      ...existingPost,
      title,
      slug,
      content,
      excerpt,
      category,
      author: author || existingPost.author,
      image: req.file ? `/uploads/${req.file.filename}` : existingPost.image
    };
    
    posts[postIndex] = updatedPost;
    await writePosts(posts);
    
    res.json(updatedPost);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Delete post (admin only)
app.delete('/api/posts/:id', verifyToken, async (req, res) => {
  try {
    const posts = await readPosts();
    const postIndex = posts.findIndex(p => p.id === req.params.id);
    
    if (postIndex === -1) {
      return res.status(404).json({ message: 'Post not found' });
    }
    
    posts.splice(postIndex, 1);
    await writePosts(posts);
    
    res.json({ message: 'Post deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Contact form submission
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;
    
    const mailOptions = {
      from: process.env.EMAIL_USER || 'your-email@gmail.com',
      to: 'zukhruf402@gmail.com',
      subject: `Contact Form: ${subject}`,
      html: `
        <h3>New Contact Form Submission</h3>
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Subject:</strong> ${subject}</p>
        <p><strong>Message:</strong></p>
        <p>${message.replace(/\n/g, '<br>')}</p>
      `
    };
    
    await transporter.sendMail(mailOptions);
    res.json({ message: 'Message sent successfully' });
  } catch (error) {
    console.error('Email error:', error);
    res.status(500).json({ message: 'Failed to send message', error: error.message });
  }
});

// Get categories (public)
app.get('/api/categories', async (req, res) => {
  try {
    const posts = await readPosts();
    const categories = [...new Set(posts.map(post => post.category))];
    res.json(['All', ...categories]);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Initialize and start server
initializeDataFiles().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Admin login: username: admin, password: admin123`);
  });
});