# DeepScan - AI Deepfake Detector

A fully functional web application for detecting deepfakes with a complete blog system and admin dashboard.

## Features

- **Deepfake Detection**: Upload and analyze images/videos for potential manipulation
- **Dynamic Blog System**: Full CRUD operations with admin dashboard
- **Admin Panel**: Secure login system for managing blog posts
- **Contact System**: Email integration for contact form submissions
- **Responsive Design**: Works on all devices with modern UI/UX

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Create a `.env` file in the root directory:
```env
EMAIL_USER=your-gmail@gmail.com
EMAIL_PASS=your-app-password
JWT_SECRET=your-secret-key-here
PORT=3001
```

**Important**: For Gmail, you need to:
1. Enable 2-factor authentication
2. Generate an "App Password" (not your regular password)
3. Use the app password in EMAIL_PASS

### 3. Start the Application
```bash
# Start both frontend and backend
npm run dev:full

# Or start them separately:
# Backend only
npm run server

# Frontend only (in another terminal)
npm run dev
```

### 4. Access the Application
- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:3001
- **Admin Panel**: Click the "+" button on the blog page

### 5. Admin Login
- **Username**: admin
- **Password**: admin123

## Blog System Features

### Admin Dashboard
- Create, edit, and delete blog posts
- Upload featured images
- Organize posts by categories
- Real-time preview and management

### Public Blog
- Search functionality
- Category filtering
- Responsive card layout
- SEO-friendly URLs

### Content Management
- Rich text content support
- Image upload and management
- Automatic excerpt generation
- Date and author tracking

## Contact System

The contact form automatically sends emails to `zukhruf402@gmail.com` with:
- Visitor's name and email
- Subject and message content
- Formatted HTML email template

## File Structure

```
├── server/
│   ├── index.js          # Express server and API routes
│   ├── data/             # JSON data storage
│   └── uploads/          # Image uploads
├── src/
│   ├── components/       # React components
│   ├── services/         # API service layer
│   └── ...
└── package.json
```

## API Endpoints

### Blog Posts
- `GET /api/posts` - Get all posts (with search/filter)
- `GET /api/posts/:slug` - Get single post
- `POST /api/posts` - Create post (admin only)
- `PUT /api/posts/:id` - Update post (admin only)
- `DELETE /api/posts/:id` - Delete post (admin only)

### Admin
- `POST /api/admin/login` - Admin authentication

### Contact
- `POST /api/contact` - Send contact form email

### Categories
- `GET /api/categories` - Get all categories

## Production Deployment

1. Set up environment variables on your hosting platform
2. Configure email service (Gmail or SMTP)
3. Ensure file upload directory permissions
4. Set up SSL certificate for secure admin login

## Security Features

- JWT-based admin authentication
- Password hashing with bcrypt
- File upload validation
- CORS protection
- Input sanitization

## Support

For issues or questions, contact: zukhruf402@gmail.com
WhatsApp: 03343142971