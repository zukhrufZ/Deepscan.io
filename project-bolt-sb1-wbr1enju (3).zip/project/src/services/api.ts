const API_BASE_URL = 'http://localhost:3001/api';

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  category: string;
  author: string;
  date: string;
  image?: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  subject: string;
  message: string;
}

class ApiService {
  private getAuthHeaders() {
    const token = localStorage.getItem('adminToken');
    return {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` })
    };
  }

  // Blog Posts
  async getPosts(category?: string, search?: string): Promise<BlogPost[]> {
    const params = new URLSearchParams();
    if (category) params.append('category', category);
    if (search) params.append('search', search);
    
    const response = await fetch(`${API_BASE_URL}/posts?${params}`);
    if (!response.ok) throw new Error('Failed to fetch posts');
    return response.json();
  }

  async getPost(slug: string): Promise<BlogPost> {
    const response = await fetch(`${API_BASE_URL}/posts/${slug}`);
    if (!response.ok) throw new Error('Failed to fetch post');
    return response.json();
  }

  async createPost(formData: FormData): Promise<BlogPost> {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE_URL}/posts`, {
      method: 'POST',
      headers: {
        ...(token && { Authorization: `Bearer ${token}` })
      },
      body: formData
    });
    if (!response.ok) throw new Error('Failed to create post');
    return response.json();
  }

  async updatePost(id: string, formData: FormData): Promise<BlogPost> {
    const token = localStorage.getItem('adminToken');
    const response = await fetch(`${API_BASE_URL}/posts/${id}`, {
      method: 'PUT',
      headers: {
        ...(token && { Authorization: `Bearer ${token}` })
      },
      body: formData
    });
    if (!response.ok) throw new Error('Failed to update post');
    return response.json();
  }

  async deletePost(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/posts/${id}`, {
      method: 'DELETE',
      headers: this.getAuthHeaders()
    });
    if (!response.ok) throw new Error('Failed to delete post');
  }

  // Categories
  async getCategories(): Promise<string[]> {
    const response = await fetch(`${API_BASE_URL}/categories`);
    if (!response.ok) throw new Error('Failed to fetch categories');
    return response.json();
  }

  // Admin Authentication
  async login(username: string, password: string): Promise<{ token: string; message: string }> {
    const response = await fetch(`${API_BASE_URL}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    if (!response.ok) throw new Error('Invalid credentials');
    return response.json();
  }

  // Contact Form
  async submitContact(data: ContactFormData): Promise<{ message: string }> {
    const response = await fetch(`${API_BASE_URL}/contact`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!response.ok) throw new Error('Failed to send message');
    return response.json();
  }

  // Auth helpers
  isAuthenticated(): boolean {
    return !!localStorage.getItem('adminToken');
  }

  logout(): void {
    localStorage.removeItem('adminToken');
  }
}

export const apiService = new ApiService();