import React, { useState, useRef, useCallback } from 'react';
import { Upload, FileImage, FileVideo, AlertTriangle, CheckCircle, Loader, X } from 'lucide-react';

const Detector: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<{
    isDeepfake: boolean;
    confidence: number;
    details: string[];
  } | null>(null);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFile = (file: File) => {
    const validTypes = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload a valid image (JPEG, PNG, WebP) or video (MP4, WebM) file.');
      return;
    }
    
    if (file.size > 50 * 1024 * 1024) { // 50MB limit
      alert('File size should be less than 50MB.');
      return;
    }

    setUploadedFile(file);
    setAnalysisResult(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const startAnalysis = async () => {
    if (!uploadedFile) return;

    setIsAnalyzing(true);
    setAnalysisProgress(0);

    // Simulate analysis progress
    const progressInterval = setInterval(() => {
      setAnalysisProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return prev;
        }
        return prev + Math.random() * 15;
      });
    }, 200);

    // Simulate analysis time
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    clearInterval(progressInterval);
    setAnalysisProgress(100);

    // Generate random result for demo
    const isDeepfake = Math.random() > 0.5;
    const confidence = Math.floor(Math.random() * 30 + 70); // 70-99%

    const deepfakeDetails = [
      "Temporal inconsistencies detected in facial movements",
      "Unnatural lighting patterns around facial features",
      "Compression artifacts suggest digital manipulation",
      "Facial landmarks show slight distortions"
    ];

    const authenticDetails = [
      "Natural facial movements and expressions detected",
      "Consistent lighting and shadow patterns",
      "No digital manipulation artifacts found",
      "Facial landmarks appear natural and consistent"
    ];

    setTimeout(() => {
      setAnalysisResult({
        isDeepfake,
        confidence,
        details: isDeepfake ? deepfakeDetails : authenticDetails
      });
      setIsAnalyzing(false);
    }, 500);
  };

  const resetAnalysis = () => {
    setUploadedFile(null);
    setAnalysisResult(null);
    setIsAnalyzing(false);
    setAnalysisProgress(0);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  const getFileIcon = (file: File) => {
    return file.type.startsWith('video/') ? (
      <FileVideo className="w-8 h-8 text-cyan-400" />
    ) : (
      <FileImage className="w-8 h-8 text-purple-400" />
    );
  };

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12 animate-fadeInUp">
          <h1 className="text-4xl sm:text-5xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            Deepfake Detector
          </h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Upload an image or video to analyze for potential deepfake manipulation
          </p>
        </div>

        <div className="space-y-8 animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
          {/* Upload Section */}
          {!uploadedFile && (
            <div className="relative">
              <div
                className={`border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 floating-card ${
                  dragActive 
                    ? 'border-cyan-500 bg-cyan-500/10' 
                    : 'border-gray-600 hover:border-cyan-500/50 bg-gray-800/30 backdrop-blur-sm'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                <Upload className={`w-16 h-16 mx-auto mb-4 transition-colors duration-300 ${
                  dragActive ? 'text-cyan-400' : 'text-gray-500'
                }`} />
                <h3 className="text-xl font-semibold mb-2 text-white">
                  Drop your file here, or click to browse
                </h3>
                <p className="text-gray-400 mb-6">
                  Supports JPEG, PNG, WebP images and MP4, WebM videos (max 50MB)
                </p>
                <button
                  onClick={() => inputRef.current?.click()}
                  className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl font-semibold text-white hover:shadow-lg hover:shadow-cyan-500/30 transform hover:scale-105 transition-all duration-300"
                >
                  Select File
                </button>
                <input
                  ref={inputRef}
                  type="file"
                  accept="image/*,video/*"
                  onChange={handleInputChange}
                  className="hidden"
                />
              </div>
            </div>
          )}

          {/* File Preview */}
          {uploadedFile && !isAnalyzing && !analysisResult && (
            <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 floating-card">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-white">File Selected</h3>
                <button
                  onClick={resetAnalysis}
                  className="p-2 text-gray-400 hover:text-red-400 transition-colors duration-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <div className="flex items-center space-x-4 mb-6 p-4 bg-gray-700/30 rounded-xl">
                {getFileIcon(uploadedFile)}
                <div className="flex-1">
                  <div className="font-medium text-white">{uploadedFile.name}</div>
                  <div className="text-sm text-gray-400">
                    {(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB
                  </div>
                </div>
              </div>

              <button
                onClick={startAnalysis}
                className="w-full px-6 py-4 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl font-semibold text-white hover:shadow-xl hover:shadow-cyan-500/50 transform hover:scale-[1.02] transition-all duration-300 flex items-center justify-center space-x-2"
              >
                <span>Analyze File</span>
                <AlertTriangle className="w-5 h-5" />
              </button>
            </div>
          )}

          {/* Analysis Progress */}
          {isAnalyzing && (
            <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 text-center floating-card">
              <div className="mb-6">
                <Loader className="w-16 h-16 mx-auto text-cyan-400 animate-spin" />
              </div>
              <h3 className="text-xl font-semibold mb-4 text-white">Analyzing...</h3>
              <div className="max-w-xs mx-auto mb-4">
                <div className="bg-gray-700/50 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-purple-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${analysisProgress}%` }}
                  ></div>
                </div>
              </div>
              <p className="text-gray-400">
                Running advanced AI detection algorithms...
              </p>
            </div>
          )}

          {/* Analysis Result */}
          {analysisResult && (
            <div className={`bg-gray-800/30 backdrop-blur-sm border rounded-2xl p-8 floating-card ${
              analysisResult.isDeepfake ? 'border-red-500/50' : 'border-green-500/50'
            }`}>
              <div className="text-center mb-6">
                {analysisResult.isDeepfake ? (
                  <AlertTriangle className="w-16 h-16 mx-auto text-red-400 mb-4" />
                ) : (
                  <CheckCircle className="w-16 h-16 mx-auto text-green-400 mb-4" />
                )}
                
                <h3 className={`text-2xl font-bold mb-2 ${
                  analysisResult.isDeepfake ? 'text-red-400' : 'text-green-400'
                }`}>
                  {analysisResult.isDeepfake ? 'Likely Deepfake' : 'Likely Authentic'}
                </h3>
                
                <p className="text-lg text-gray-300 mb-4">
                  Confidence: {analysisResult.confidence}%
                </p>
              </div>

              <div className="space-y-3 mb-6">
                <h4 className="font-semibold text-white">Analysis Details:</h4>
                {analysisResult.details.map((detail, index) => (
                  <div key={index} className="flex items-start space-x-2 text-sm text-gray-300">
                    <div className="w-2 h-2 rounded-full bg-cyan-400 mt-2 flex-shrink-0"></div>
                    <span>{detail}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={resetAnalysis}
                  className="flex-1 px-6 py-3 bg-gray-700 hover:bg-gray-600 rounded-xl font-semibold text-white transition-all duration-300"
                >
                  Analyze Another File
                </button>
                <button
                  onClick={() => {
                    const result = {
                      fileName: uploadedFile?.name,
                      isDeepfake: analysisResult.isDeepfake,
                      confidence: analysisResult.confidence,
                      timestamp: new Date().toISOString()
                    };
                    const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `deepscan-result-${Date.now()}.json`;
                    a.click();
                    URL.revokeObjectURL(url);
                  }}
                  className="flex-1 px-6 py-3 border border-cyan-500/50 hover:bg-cyan-500/10 rounded-xl font-semibold text-cyan-400 transition-all duration-300"
                >
                  Download Report
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Detector;