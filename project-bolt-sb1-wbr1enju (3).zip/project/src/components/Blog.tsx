import React, { useState, useEffect } from 'react';
import { Calendar, Clock, ArrowRight, Search, Filter, Plus } from 'lucide-react';
import { apiService, BlogPost } from '../services/api';
import AdminLogin from './AdminLogin';
import AdminDashboard from './AdminDashboard';

const Blog: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [showAdmin, setShowAdmin] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);

  useEffect(() => {
    loadPosts();
    loadCategories();
  }, [selectedCategory, searchTerm]);

  const loadPosts = async () => {
    try {
      setLoading(true);
      const fetchedPosts = await apiService.getPosts(
        selectedCategory === 'All' ? undefined : selectedCategory,
        searchTerm || undefined
      );
      setPosts(fetchedPosts);
    } catch (error) {
      console.error('Error loading posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadCategories = async () => {
    try {
      const fetchedCategories = await apiService.getCategories();
      setCategories(fetchedCategories);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    loadPosts();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const calculateReadTime = (content: string) => {
    const wordsPerMinute = 200;
    const wordCount = content.split(' ').length;
    const readTime = Math.ceil(wordCount / wordsPerMinute);
    return `${readTime} min read`;
  };

  if (showDashboard && apiService.isAuthenticated()) {
    return <AdminDashboard onBack={() => setShowDashboard(false)} onPostsUpdate={loadPosts} />;
  }

  if (showAdmin) {
    return (
      <AdminLogin 
        onBack={() => setShowAdmin(false)}
        onLoginSuccess={() => {
          setShowAdmin(false);
          setShowDashboard(true);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fadeInUp">
          <div className="flex items-center justify-center space-x-4 mb-4">
            <h1 className="text-4xl sm:text-5xl font-bold bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
              DeepScan Blog
            </h1>
            <button
              onClick={() => apiService.isAuthenticated() ? setShowDashboard(true) : setShowAdmin(true)}
              className="p-2 bg-gray-800/50 hover:bg-gray-700/50 rounded-lg transition-colors duration-200"
              title="Admin Panel"
            >
              <Plus className="w-5 h-5 text-gray-400 hover:text-cyan-400" />
            </button>
          </div>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Stay informed about deepfakes, AI security, and digital media authentication
          </p>
        </div>

        {/* Search and Filter */}
        <div className="mb-12 animate-fadeInUp" style={{ animationDelay: '0.1s' }}>
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-gray-800/50 border border-gray-600 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all duration-300"
                />
              </div>
            </form>

            {/* Category Filter */}
            <div className="flex items-center space-x-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-gray-800/50 border border-gray-600 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan-500/50 focus:ring-2 focus:ring-cyan-500/20 transition-all duration-300"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center py-12">
            <div className="animate-spin w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full mx-auto mb-4"></div>
            <p className="text-gray-400">Loading articles...</p>
          </div>
        )}

        {/* No Posts */}
        {!loading && posts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-400 text-lg">No articles found.</p>
            {(searchTerm || selectedCategory !== 'All') && (
              <button
                onClick={() => {
                  setSearchTerm('');
                  setSelectedCategory('All');
                }}
                className="mt-4 px-6 py-2 bg-cyan-500/20 border border-cyan-500/30 rounded-xl text-cyan-400 hover:bg-cyan-500/30 transition-all duration-300"
              >
                Clear Filters
              </button>
            )}
          </div>
        )}

        {/* Articles Grid */}
        {!loading && posts.length > 0 && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map((post, index) => (
              <article
                key={post.id}
                className="group bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl overflow-hidden hover:border-cyan-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/10 animate-fadeInUp floating-card"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {post.image && (
                  <div className="relative overflow-hidden">
                    <img
                      src={`http://localhost:3001${post.image}`}
                      alt={post.title}
                      className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 to-transparent"></div>
                    <div className="absolute top-4 left-4 px-3 py-1 bg-gray-900/80 backdrop-blur-sm rounded-full text-sm font-medium text-cyan-400">
                      {post.category}
                    </div>
                  </div>
                )}

                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3 text-white group-hover:text-cyan-400 transition-colors duration-300 line-clamp-2">
                    {post.title}
                  </h3>
                  
                  <p className="text-gray-400 mb-4 line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>

                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <span className="font-medium">{post.author}</span>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{formatDate(post.date)}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{calculateReadTime(post.content)}</span>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => window.open(`/blog/${post.slug}`, '_blank')}
                    className="group/btn w-full flex items-center justify-center space-x-2 py-3 px-4 bg-gradient-to-r from-cyan-500/20 to-purple-600/20 border border-cyan-500/30 rounded-xl font-medium text-cyan-400 hover:from-cyan-500/30 hover:to-purple-600/30 hover:shadow-lg hover:shadow-cyan-500/20 transition-all duration-300"
                  >
                    <span>Read More</span>
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Blog;