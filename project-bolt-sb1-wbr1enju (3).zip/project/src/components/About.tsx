import React from 'react';
import { Shield, Users, Target, Zap, Eye, Brain, Award, Globe } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Advanced AI Detection",
      description: "Multi-layer neural networks trained on millions of synthetic and authentic media samples"
    },
    {
      icon: <Eye className="w-8 h-8" />,
      title: "Real-time Analysis",
      description: "Lightning-fast processing that delivers results in under 3 seconds"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Privacy First",
      description: "Your files are processed securely and never stored on our servers"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Continuous Learning",
      description: "Our models are constantly updated with the latest deepfake techniques"
    }
  ];

  const stats = [
    { icon: <Globe className="w-6 h-6" />, number: "1M+", label: "Files Analyzed" },
    { icon: <Award className="w-6 h-6" />, number: "99.8%", label: "Accuracy Rate" },
    { icon: <Users className="w-6 h-6" />, number: "50K+", label: "Users Protected" },
    { icon: <Shield className="w-6 h-6" />, number: "24/7", label: "Uptime" }
  ];

  return (
    <div className="min-h-screen py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-20 animate-fadeInUp">
          <h1 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent">
            About DeepScan
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            We're on a mission to protect digital truth in an age of AI-generated misinformation. 
            Our cutting-edge technology empowers individuals and organizations to identify synthetic media with confidence.
          </p>
        </div>

        {/* Mission Section */}
        <section className="mb-20 animate-fadeInUp" style={{ animationDelay: '0.1s' }}>
          <div className="bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 lg:p-12 floating-card">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="flex items-center space-x-3 mb-6">
                  <Target className="w-8 h-8 text-cyan-400" />
                  <h2 className="text-3xl font-bold text-white">Our Mission</h2>
                </div>
                <p className="text-lg text-gray-300 mb-6 leading-relaxed">
                  In an era where synthetic media can be created with alarming ease, we believe everyone deserves 
                  the tools to distinguish between authentic and manipulated content. Our mission is to democratize 
                  access to advanced deepfake detection technology.
                </p>
                <p className="text-gray-400 leading-relaxed">
                  By combining state-of-the-art AI research with user-friendly interfaces, we're building 
                  a safer digital ecosystem where truth prevails over deception.
                </p>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-600/20 rounded-2xl blur-xl"></div>
                <div className="relative bg-gray-900/50 backdrop-blur-sm border border-cyan-500/30 rounded-2xl p-8">
                  <div className="grid grid-cols-2 gap-4">
                    {stats.map((stat, index) => (
                      <div key={index} className="text-center">
                        <div className="flex justify-center mb-2 text-cyan-400">
                          {stat.icon}
                        </div>
                        <div className="text-2xl font-bold text-white">{stat.number}</div>
                        <div className="text-sm text-gray-400">{stat.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="mb-20">
          <div className="text-center mb-12 animate-fadeInUp" style={{ animationDelay: '0.2s' }}>
            <h2 className="text-3xl font-bold mb-4 text-white">How DeepScan Works</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">
              Our multi-layered approach combines multiple detection techniques for maximum accuracy
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group p-6 bg-gray-800/30 backdrop-blur-sm border border-gray-700/50 rounded-2xl hover:border-cyan-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/10 animate-fadeInUp floating-card"
                style={{ animationDelay: `${0.3 + index * 0.1}s` }}
              >
                <div className="flex items-center justify-center w-16 h-16 rounded-xl bg-gradient-to-r from-cyan-500/20 to-purple-600/20 border border-cyan-500/30 mb-6 group-hover:scale-110 transition-transform duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold mb-3 text-white group-hover:text-cyan-400 transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-gray-400 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Section */}
        <section className="text-center animate-fadeInUp" style={{ animationDelay: '0.4s' }}>
          <div className="bg-gradient-to-r from-cyan-500/10 to-purple-600/10 backdrop-blur-sm border border-cyan-500/20 rounded-2xl p-12 floating-card">
            <h2 className="text-3xl font-bold mb-4 text-white">Ready to Detect Deepfakes?</h2>
            <p className="text-xl text-gray-400 mb-8 max-w-2xl mx-auto">
              Join thousands of users protecting themselves from AI-generated misinformation
            </p>
            <button className="px-8 py-4 bg-gradient-to-r from-cyan-500 to-purple-600 rounded-xl font-semibold text-white hover:shadow-xl hover:shadow-cyan-500/50 transform hover:scale-105 transition-all duration-300">
              Start Detection Now
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};

export default About;