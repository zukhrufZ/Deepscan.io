import React from 'react';

const GeometricBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Primary geometric pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="islamic-pattern-1" x="0" y="0" width="200" height="200" patternUnits="userSpaceOnUse">
              <g stroke="currentColor" strokeWidth="1" fill="none" className="text-cyan-500">
                <circle cx="100" cy="100" r="50" className="animate-spin-slow" />
                <circle cx="100" cy="100" r="30" className="animate-spin-reverse" />
                <path d="M50,50 L150,50 L150,150 L50,150 Z" className="animate-pulse" />
                <path d="M75,75 L125,75 L125,125 L75,125 Z" />
                <line x1="100" y1="0" x2="100" y2="200" />
                <line x1="0" y1="100" x2="200" y2="100" />
              </g>
            </pattern>
            <pattern id="islamic-pattern-2" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
              <g stroke="currentColor" strokeWidth="0.5" fill="none" className="text-purple-500">
                <polygon points="50,10 90,50 50,90 10,50" className="animate-pulse" />
                <circle cx="50" cy="50" r="20" />
              </g>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#islamic-pattern-1)" />
          <rect width="100%" height="100%" fill="url(#islamic-pattern-2)" />
        </svg>
      </div>

      {/* Secondary floating elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-32 h-32 border border-cyan-500/30 rounded-full animate-float"></div>
        <div className="absolute top-40 right-20 w-24 h-24 border border-purple-500/30 rounded-lg animate-float-delay"></div>
        <div className="absolute bottom-32 left-1/4 w-20 h-20 border border-cyan-400/30 rounded-full animate-pulse"></div>
        <div className="absolute bottom-20 right-1/3 w-28 h-28 border border-purple-400/30 rounded-lg animate-float"></div>
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-900/10 via-transparent to-purple-900/10"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-gray-900/50 to-transparent"></div>
    </div>
  );
};

export default GeometricBackground;